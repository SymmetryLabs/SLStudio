/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/22/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx;

public interface Touch {
	public double getX();
	public double getY();
	public boolean isActive();
	
	public class NullTouch implements Touch {
		public double getX() {
			return -1;
		}
		public double getY() {
			return -1;
		}
		public boolean isActive() {
			return false;
		}
	}
}
