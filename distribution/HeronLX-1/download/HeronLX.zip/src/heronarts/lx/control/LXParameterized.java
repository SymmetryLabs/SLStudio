/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    05/26/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.control;

import java.util.ArrayList;
import java.util.List;

public abstract class LXParameterized implements LXListenableParameter.Listener {
	
	private final List<LXParameter> parameters = new ArrayList<LXParameter>();
	
	protected final void addParameter(LXParameter parameter) {
		parameters.add(parameter);
		if (parameter instanceof LXListenableParameter) {
			((LXListenableParameter)parameter).addListener(this);
		}
	}
	
	public final List<LXParameter> getParameters() {
		return parameters;
	}
	
	public /* abstract */ void onParameterChanged(LXParameter parameter) {}
}
