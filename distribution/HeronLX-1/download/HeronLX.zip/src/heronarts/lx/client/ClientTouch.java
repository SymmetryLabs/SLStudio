/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/22/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.client;

import heronarts.lx.Touch;

public class ClientTouch implements Touch {
	private double x = -1;
	private double y = -1;
	private boolean isActive = false;
	
	void setX(double x) {
		this.x = x;
	}
	
	void setY(double y) {
		this.y = y;
	}
	
	void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
	
	public boolean isActive() {
		return this.isActive;
	}

}
