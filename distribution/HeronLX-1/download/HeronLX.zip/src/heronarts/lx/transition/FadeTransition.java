/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    05/26/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.transition;


import heronarts.lx.HeronLX;

import java.lang.Math;

public class FadeTransition extends LXTransition {
	
	public FadeTransition(HeronLX lx) {
		super(lx);
	}
	
	protected void computeBlend(int[] c1, int[] c2, double progress) {
		int[] c = (progress < 0.5) ? c1 : c2;
		double b = Math.abs(progress - 0.5) * 2.;
		
		for (int i = 0; i < this.colors.length; ++i) {
			this.colors[i] = this.lx.applet.color(
				this.lx.applet.hue(c[i]),
				this.lx.applet.saturation(c[i]),
				(float) (b * this.lx.applet.brightness(c[i]))
				);
		}
	}
}
