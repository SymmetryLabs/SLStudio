/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/20/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.pattern;

import heronarts.lx.HeronLX;
import heronarts.lx.modulator.SawLFO;

/**
 * Braindead simple test pattern that iterates through all the nodes turning
 * them on one by one in fixed order.
 */
public class IteratorTestPattern extends LXPattern {

	final private SawLFO index;

	public IteratorTestPattern(HeronLX lx) {
		super(lx);
		this.addModulator(this.index = new SawLFO(0, lx.total, lx.total * 100)).trigger();
	}

	public void run(int deltaMs) {
		int active = (int) Math.floor(this.index.getValue()); 
		for (int i = 0; i < colors.length; ++i) {
			this.colors[i] = (i == active) ? 0xFFFFFFFF : 0xFF000000;
		}
	}
}
