/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/22/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.pattern;
import heronarts.lx.HeronLX;

import processing.core.PConstants;
import processing.core.PGraphics;

public abstract class LXGraphicsPattern extends LXPattern {

	private final PGraphics g;
	
	protected LXGraphicsPattern(HeronLX lx) {
		super(lx);
		this.g = lx.applet.createGraphics(lx.width, lx.height, PConstants.P2D);
	}
	
	final protected void run(int deltaMs) {
		this.g.beginDraw();
		this.run(deltaMs, this.g);
		this.g.endDraw();
		this.g.loadPixels();
		for (int i = 0; i < this.lx.total; ++i) {
			this.colors[i] = this.g.pixels[i];
		}
	}
	
	abstract protected void run(int deltaMs, PGraphics g);

}
