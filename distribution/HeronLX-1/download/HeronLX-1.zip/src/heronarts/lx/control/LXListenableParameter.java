/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    06/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.control;

import java.util.HashSet;
import java.util.Set;

public abstract class LXListenableParameter extends LXParameter {

	private final Set<Listener> listeners = new HashSet<Listener>();
	
	public final void addListener(Listener listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}
	
	public final void removeListener(Listener listener) {
		listeners.remove(listener);
	}

	@Override
	public final void setValue(double value) {
		if (value != getValue()) {
			updateValue(value);
			for (Listener l : listeners) {
				l.onParameterChanged(this);
			}
		}
	}
	
	protected abstract void updateValue(double value);
	
}
