/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    09/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.pattern;

import heronarts.lx.HeronLX;

public class SolidColorPattern extends LXPattern {
	final int color;
	
	public SolidColorPattern(HeronLX lx, int color) {
		super(lx);
		this.color = color;
		for (int i = 0; i < this.colors.length; ++i) {
			this.colors[i] = color;
		}
	}
	
	public void run(int deltaMs) {}
}
