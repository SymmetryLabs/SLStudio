/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    09/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.kinet;

public class KinetNode {
	final public KinetPort outputPort;
	final public int nodeIndex;
	
	public KinetNode(KinetPort outputPort, int nodeIndex) {
		if (outputPort == null) {
			throw new NullPointerException();
		}
		this.outputPort = outputPort;
		this.nodeIndex = nodeIndex;
	}
}
