/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    09/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.modulator;

public class QuadraticEnvelope extends RangeModulator {

	public enum Ease {
		IN,
		OUT,
		BOTH
	};

	private Ease ease = Ease.IN;
	
	public QuadraticEnvelope(double startValue, double endValue, double periodMs) {
		super(startValue, endValue, periodMs);
		this.looping = false;
	}
	
	public QuadraticEnvelope setEase(Ease ease) {
		this.ease = ease;
		return this;
	}
	
	@Override
	protected double computeNormalizedValue(int deltaMs) {
		final double bv = getBasis();
		switch (this.ease) {
		case IN:
			return bv*bv;
		case OUT:
			return 1 - (1-bv)*(1-bv);
		case BOTH:
			if (bv < 0.5) {
				return (bv*2)*(bv*2) / 2.;
			} else {
				final double biv = 1 - (bv-0.5) * 2.;
				return 0.5 + (1-biv*biv) / 2.;
			}
		}
		return 0;
	}
			
	@Override
	protected double computeBasisFromNormalizedValue(double normalizedValue) {
		switch (this.ease) {
		case IN:
			return Math.sqrt(normalizedValue);
		case OUT:
			return 1 - Math.sqrt(1 - normalizedValue);
		case BOTH:
			if (normalizedValue < 0.5) {
				normalizedValue = normalizedValue*2;
				return Math.sqrt(normalizedValue) / 2.;
			} else {
				normalizedValue = (normalizedValue-0.5)*2;
				return 0.5 + (1 - Math.sqrt(1 - normalizedValue)) / 2.;
			}
		}
		return 0;
	}
		
}
