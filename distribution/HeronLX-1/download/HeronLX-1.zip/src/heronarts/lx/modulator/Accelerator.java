/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    09/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.modulator;

public class Accelerator extends LXModulator {
	
	private double initValue;
	private double initVelocity;
	
	private double velocity;
	private double acceleration;

	public Accelerator(double initValue, double initVelocity, double acceleration) {
		setValue(this.initValue = initValue);
		setSpeed(initVelocity, acceleration);
	}

	protected void onTrigger() {
		this.velocity = this.initVelocity;
		setValue(this.initValue);
	}
	
	public double getVelocity() {
		return this.velocity;
	}
	
	public float getVelocityf() {
		return (float)this.getVelocity();
	}
	
	public Accelerator setSpeed(double initVelocity, double acceleration) {
		this.velocity = this.initVelocity = initVelocity;
		this.acceleration = acceleration;
		return this;
	}
	
	public Accelerator setVelocity(double velocity) {
		this.velocity = velocity;
		return this;
	}
	
	public Accelerator setAcceleration(double acceleration) {
		this.acceleration = acceleration;
		return this;
	}
	
	@Override
	protected double computeValue(int deltaMs) {
		this.velocity += this.acceleration * deltaMs / 1000.0;
		return this.getValue() + this.velocity * deltaMs / 1000.0;
	}
	
	@Override
	protected double computeBasis() {
		// This is undefined/irrelevant for an Accelerator
		return 0;
	}
}