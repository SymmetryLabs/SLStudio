/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    09/12/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.modulator;

/**
 * Simple square wave LFO. Not damped. Oscillates between a low and high value.
 */
public class SquareLFO extends RangeModulator {

	public SquareLFO(double startValue, double endValue, double periodMs) {
		super(startValue, endValue, periodMs);
	}

	@Override
	protected double computeNormalizedValue(int deltaMs) {
		return (getBasis() < 0.5) ? 0 : 1;
	}
	
	@Override
	protected double computeBasisFromNormalizedValue(double normalizedValue) {
		return (normalizedValue == 0) ? 0 : 0.5;
	}

}
